import './assets/index.ts-B6jpnAry.js';
